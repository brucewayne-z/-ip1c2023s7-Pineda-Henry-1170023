﻿namespace _1170023_Henry_Pineda
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            button1 = new Button();
            groupBox1 = new GroupBox();
            comboBox1 = new ComboBox();
            Sumatoria = new TabControl();
            tabPage1 = new TabPage();
            textBox2 = new TextBox();
            label2 = new Label();
            textBox1 = new TextBox();
            label1 = new Label();
            tabPage2 = new TabPage();
            tabPage3 = new TabPage();
            tabPage4 = new TabPage();
            groupBox1.SuspendLayout();
            Sumatoria.SuspendLayout();
            tabPage1.SuspendLayout();
            SuspendLayout();
            // 
            // button1
            // 
            button1.Location = new Point(128, 233);
            button1.Name = "button1";
            button1.Size = new Size(151, 32);
            button1.TabIndex = 0;
            button1.Text = "Seleccionar";
            button1.UseVisualStyleBackColor = true;
            button1.UseWaitCursor = true;
            button1.Click += button1_Click;
            // 
            // groupBox1
            // 
            groupBox1.Controls.Add(comboBox1);
            groupBox1.Location = new Point(80, 64);
            groupBox1.Name = "groupBox1";
            groupBox1.Size = new Size(250, 125);
            groupBox1.TabIndex = 1;
            groupBox1.TabStop = false;
            groupBox1.Text = "Selección";
            // 
            // comboBox1
            // 
            comboBox1.FormattingEnabled = true;
            comboBox1.Items.AddRange(new object[] { "Sumatoria", "Factorial", "Número perfecto", "Tablas de multiplicar" });
            comboBox1.Location = new Point(48, 51);
            comboBox1.Name = "comboBox1";
            comboBox1.Size = new Size(151, 28);
            comboBox1.TabIndex = 0;
            comboBox1.SelectedIndexChanged += comboBox1_SelectedIndexChanged;
            // 
            // Sumatoria
            // 
            Sumatoria.Controls.Add(tabPage1);
            Sumatoria.Controls.Add(tabPage2);
            Sumatoria.Controls.Add(tabPage3);
            Sumatoria.Controls.Add(tabPage4);
            Sumatoria.Location = new Point(336, 64);
            Sumatoria.Name = "Sumatoria";
            Sumatoria.SelectedIndex = 0;
            Sumatoria.Size = new Size(453, 314);
            Sumatoria.TabIndex = 2;
            // 
            // tabPage1
            // 
            tabPage1.BackColor = Color.AntiqueWhite;
            tabPage1.BorderStyle = BorderStyle.Fixed3D;
            tabPage1.Controls.Add(textBox2);
            tabPage1.Controls.Add(label2);
            tabPage1.Controls.Add(textBox1);
            tabPage1.Controls.Add(label1);
            tabPage1.Cursor = Cursors.Hand;
            tabPage1.ForeColor = SystemColors.HotTrack;
            tabPage1.Location = new Point(4, 29);
            tabPage1.Name = "tabPage1";
            tabPage1.Padding = new Padding(3);
            tabPage1.Size = new Size(445, 281);
            tabPage1.TabIndex = 0;
            tabPage1.Text = "Sumatoria";
            tabPage1.Click += tabPage1_Click;
            // 
            // textBox2
            // 
            textBox2.Location = new Point(143, 127);
            textBox2.Name = "textBox2";
            textBox2.Size = new Size(37, 27);
            textBox2.TabIndex = 3;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.ForeColor = SystemColors.ControlDarkDark;
            label2.Location = new Point(33, 130);
            label2.Name = "label2";
            label2.Size = new Size(78, 20);
            label2.TabIndex = 2;
            label2.Text = "Resultado:";
            label2.Click += label2_Click;
            // 
            // textBox1
            // 
            textBox1.Location = new Point(219, 52);
            textBox1.Name = "textBox1";
            textBox1.Size = new Size(158, 27);
            textBox1.TabIndex = 1;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.ForeColor = SystemColors.ControlDarkDark;
            label1.Location = new Point(29, 53);
            label1.Name = "label1";
            label1.Size = new Size(147, 20);
            label1.TabIndex = 0;
            label1.Text = "Ingrese un número N";
            // 
            // tabPage2
            // 
            tabPage2.BackColor = Color.OldLace;
            tabPage2.ForeColor = SystemColors.HotTrack;
            tabPage2.Location = new Point(4, 29);
            tabPage2.Name = "tabPage2";
            tabPage2.Padding = new Padding(3);
            tabPage2.Size = new Size(445, 281);
            tabPage2.TabIndex = 1;
            tabPage2.Text = "Factorial";
            // 
            // tabPage3
            // 
            tabPage3.BackColor = Color.Pink;
            tabPage3.ForeColor = SystemColors.HotTrack;
            tabPage3.Location = new Point(4, 29);
            tabPage3.Name = "tabPage3";
            tabPage3.Padding = new Padding(3);
            tabPage3.Size = new Size(445, 281);
            tabPage3.TabIndex = 2;
            tabPage3.Text = "Número perfecto";
            // 
            // tabPage4
            // 
            tabPage4.BackColor = Color.MediumPurple;
            tabPage4.ForeColor = SystemColors.HotTrack;
            tabPage4.Location = new Point(4, 29);
            tabPage4.Name = "tabPage4";
            tabPage4.Padding = new Padding(3);
            tabPage4.Size = new Size(445, 281);
            tabPage4.TabIndex = 3;
            tabPage4.Text = "Tablas de multiplicar";
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(Sumatoria);
            Controls.Add(groupBox1);
            Controls.Add(button1);
            Name = "Form1";
            Text = "Form1";
            groupBox1.ResumeLayout(false);
            Sumatoria.ResumeLayout(false);
            tabPage1.ResumeLayout(false);
            tabPage1.PerformLayout();
            ResumeLayout(false);
        }

        #endregion

        private Button button1;
        private GroupBox groupBox1;
        private ComboBox comboBox1;
        private TabControl Sumatoria;
        private TabPage tabPage1;
        private Label label2;
        private TextBox textBox1;
        private Label label1;
        private TabPage tabPage2;
        private TabPage tabPage3;
        private TabPage tabPage4;
        private TextBox textBox2;
    }
}
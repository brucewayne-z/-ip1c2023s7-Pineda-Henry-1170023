using Microsoft.VisualBasic;

namespace Lab
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        /// <summary>
        /// Boton que se encarga de leer una palabra ingresada por el usuario, descomponerla en 
        /// caracteres y luego mostrar caracter por caracter cuadros de mensajes.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void button1_Click(object sender, EventArgs e)
        {
            //Declaracion de variables
            string _palabra = "";
            char[] _palabraChars;
            int cont = 0;

            //Leer palabra, asignar a variable y convertirla a un arreglo de caracteres
            _palabra = textBox1.Text; //asignamos valores del form a la variable
            _palabraChars = _palabra.ToCharArray();


           
            /*
             //Otra forma de convertir a un arreglo de caracteres es por medio del foreach
            foreach (char item in _palabra)
            {
                //_palabraChars[cont] = item;
                MessageBox.Show("Caracter es: " + item);
                cont++;
            }*/

            for (int i = 0; i < _palabraChars.Length; i++)
            {
                MessageBox.Show("Caracter encontrado: " + _palabraChars[i], "Notificacion de Caracteres", MessageBoxButtons.OK ,MessageBoxIcon.Exclamation);
            }

        }

        private void button2_Click(object sender, EventArgs e)
        {
            //ahorcado
            string _palabraBase = "COPA";
            char[] _posiciones = new char[_palabraBase.Length];
            int cont=0;

            try
            {
                //conviertiendo la palabra a un arreglo de caracteres
                char[] _arrayPalabraBase = _palabraBase.ToCharArray();
                int j;
                //obteniendo caracteres del formulario
                for ( j = 0; j < _arrayPalabraBase.Length; j++) {

                    try
                    {
                        //_posiciones[j] = char.Parse(textBox3.Text);

                    }
                    catch (Exception)
                    {
                        _posiciones[j] = ' ';
                    }
                    

                }
                if (_palabraBase.Contains(textBox2.Text & textBox3.Text & textBox4.Text & textBox5.Text)
                    {
                    MessageBox.Show("La palabra es correcta, est� contenida.");
                }
                else
                {
                    MessageBox.Show("Error, la palabra no est� contenida.");
                }
                for (int i = 0; i < _palabraBase.Length; i++)
                {
                    if (_posiciones[i]!= ' ')
                    {
                        cont++;
                    }
                }

                if (cont>1)
                {
                    MessageBox.Show("Erorr: Debe de ingresar solo un caracter");
                    textBox2.Text = "";
                    textBox3.Text = "";
                    textBox4.Text = "";
                    textBox5.Text = "";
                }
            }
            catch (Exception)
            {
               MessageBox.Show("ERROR: Debe de ingresar una letra unicamente");
                textBox2.Text = "";
                textBox3.Text = "";
                textBox4.Text = "";
                textBox5.Text = "";
            }
            
            


        }
    }
}
// lo que intent� hacer es usar la propiedad .contains y hace al momento de ingresar los caracteres, estos se puedan tomar o no como parte de la palabra.
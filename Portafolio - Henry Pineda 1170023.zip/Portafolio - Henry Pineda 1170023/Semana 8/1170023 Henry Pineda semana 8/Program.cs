﻿using System;
using System.Reflection;
using System.Security.Cryptography.X509Certificates;

public class Operaciones
{
    public Operaciones() {
        double productoA, productoB, sumandoA, sumandoB, divisor, dividendo, minuendo, sutrayendo;
        double resultadoMulti, resultadoDivi, resultadoSuma, resultadoResta;

     Public void setProductos(double prodA, double prodB)
        {
            productoA= prodA;
            productoB= prodB;
        }


    }    
}

﻿namespace Menu
{
    public class Menu
    {
        public static void Main(string[] args)
        {

        }

    }



    

}


public class cMenu
    {
        private double precio = 0.0;
        private int cantidad = 0;

        public void setPrecio(double prec)
        {

            precio = prec;


        }
    public double getPrecio()
    {
        return precio;
    }

        public int getCantidad()
        {
            return cantidad;

        }
    public int setCantidad()
    {
        return cantidad;
    }


}

﻿namespace ejercicio3
{
    public class program
    {
         static void Main(string[] args)
        {
            journey = new journey();
            grade = new grade();

            name.data =  "progra";
            classroom.data = "TEC-102";
            schedule.data = "7 pm";
            creditscourse.data = "4 créditos";

            Random Svalue= new Random();

            Console.Write(Datos.MostrarClase());
            Console.WriteLine("Tu nota es: " + Svalue.Next(0, 100));


        }
    }
}public class course
{
    public string classroom;
    public string name;
    public string schedule;
    public string creditscourse;
    public string data;

    public string showclass()
    {
        data = "Su salón es:" + name;
        return data;
        data += "No: " + classroom;
        return data;
        data += "Horario: " + schedule;
        return data;
        data += "Créditos: " + creditscourse;
        return data;
    }
}



